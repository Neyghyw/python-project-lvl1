from brain_games.cli import game_template


def main():
    game_template("brain_gcd", chances=1)


if __name__ == "__main__":
    main()
