from brain_games.cli import game_template


def main():
    game_template("brain_even")


if __name__ == "__main__":
    main()
