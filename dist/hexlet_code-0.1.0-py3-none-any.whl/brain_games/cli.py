def welcome_user(name):
    print(f'Hello, {name}!')


def main():
    pass


if __name__ == '__main__':
    main()
